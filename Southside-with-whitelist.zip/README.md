# Southside

Website and whitelist system for the SOUTH SIDE roleplay server.

## Files
- index.html: home page (links to /whitelist.html)
- whitelist.html: 3-step whitelist (Discord login, server role check, application form)
- api/auth/discord.js: starts Discord login
- api/auth/callback.js: handles the Discord callback
- api/auth/logout.js: logs out
- api/whitelist/status.js: checks membership and roles (Member required, Citizens not allowed)
- api/whitelist/apply.js: receives applications and posts them to the staff review channel
- lib/: session signing and Discord role check
- vercel.json: maps /auth/callback/discord to the callback function
- .env.example: environment variables (never commit real values)

## Setup
1. Add every variable from .env.example in Vercel > Project > Settings > Environment Variables.
2. Set DISCORD_REDIRECT_URI to https://south-side-roleplay.vercel.app/auth/callback/discord
3. In Discord Developer Portal > OAuth2 > Redirects, add the same URL.
4. Invite the bot to the server and give it access to the review channel.
5. Deploy and open /whitelist.html.
