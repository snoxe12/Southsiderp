const { sign, parseCookies } = require('../../lib/session');

module.exports = async (req, res) => {
  const url = new URL(req.url, 'https://placeholder.local');
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const cookies = parseCookies(req);
  const fail = (reason) => {
    res.statusCode = 302;
    res.setHeader('Location', '/whitelist.html?error=' + reason);
    res.end();
  };

  if (!code || !state || state !== cookies.oauth_state) return fail('state');

  const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: process.env.DISCORD_CLIENT_ID,
      client_secret: process.env.DISCORD_CLIENT_SECRET,
      grant_type: 'authorization_code',
      code,
      redirect_uri: process.env.DISCORD_REDIRECT_URI,
    }),
  });
  if (!tokenRes.ok) return fail('token');
  const tok = await tokenRes.json();

  const meRes = await fetch('https://discord.com/api/users/@me', {
    headers: { Authorization: `Bearer ${tok.access_token}` },
  });
  if (!meRes.ok) return fail('user');
  const me = await meRes.json();

  const session = sign({
    id: me.id,
    username: me.global_name || me.username,
    avatar: me.avatar,
    exp: Date.now() + 7 * 24 * 3600 * 1000,
  });
  res.setHeader('Set-Cookie', [
    `session=${session}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800`,
    'oauth_state=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0',
  ]);
  res.statusCode = 302;
  res.setHeader('Location', '/whitelist.html');
  res.end();
};
