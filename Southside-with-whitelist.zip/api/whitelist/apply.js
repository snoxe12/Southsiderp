const { verify, parseCookies } = require('../../lib/session');
const { getEligibility } = require('../../lib/discord');

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 20000) { req.destroy(); reject(new Error('too large')); }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

const clean = (v, max) => String(v ?? '').trim().slice(0, max);
const send = (res, code, obj) => { res.statusCode = code; res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(obj)); };

module.exports = async (req, res) => {
  if (req.method !== 'POST') return send(res, 405, { error: 'method' });

  const user = verify(parseCookies(req).session);
  if (!user) return send(res, 401, { error: 'login' });

  // Re-check on the server: the client can't be trusted to enforce eligibility.
  const elig = await getEligibility(user.id);
  if (elig.error) return send(res, 503, { error: 'discord_unavailable' });
  if (!elig.eligible) return send(res, 403, { error: 'not_eligible' });

  let body;
  try { body = await readBody(req); } catch (e) { return send(res, 400, { error: 'bad_body' }); }

  const app = {
    character: clean(body.character, 60),
    age: clean(body.age, 3),
    backstory: clean(body.backstory, 1000),
    experience: clean(body.experience, 500),
    rules: body.rules === true,
  };
  if (!app.character || !app.age || !app.backstory || !app.experience || !app.rules) {
    return send(res, 400, { error: 'missing_fields' });
  }
  const age = parseInt(app.age, 10);
  if (!(age >= 16 && age <= 99)) return send(res, 400, { error: 'missing_fields' });

  const r = await fetch(`https://discord.com/api/v10/channels/${process.env.REVIEW_CHANNEL_ID}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bot ${process.env.DISCORD_BOT_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      embeds: [{
        title: 'New whitelist application',
        color: 0x8b5cf6,
        fields: [
          { name: 'Discord', value: `${user.username} (${user.id})` },
          { name: 'Character name', value: app.character },
          { name: 'Age', value: String(age) },
          { name: 'Character backstory', value: app.backstory },
          { name: 'Roleplay experience', value: app.experience },
        ],
        timestamp: new Date().toISOString(),
      }],
    }),
  });
  if (!r.ok) return send(res, 502, { error: 'submit_failed' });
  send(res, 200, { ok: true });
};
