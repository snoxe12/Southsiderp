const { verify, parseCookies } = require('../../lib/session');
const { getEligibility } = require('../../lib/discord');

module.exports = async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store');

  const user = verify(parseCookies(req).session);
  if (!user) return res.end(JSON.stringify({ loggedIn: false, inviteUrl: process.env.DISCORD_INVITE_URL }));

  const elig = await getEligibility(user.id);
  if (elig.error) {
    return res.end(JSON.stringify({ loggedIn: true, error: 'discord_unavailable', user: { id: user.id, username: user.username, avatar: user.avatar }, inviteUrl: process.env.DISCORD_INVITE_URL }));
  }
  res.end(JSON.stringify({
    loggedIn: true,
    inviteUrl: process.env.DISCORD_INVITE_URL,
    user: { id: user.id, username: user.username, avatar: user.avatar },
    ...elig,
  }));
};
